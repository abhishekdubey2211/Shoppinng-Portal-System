package com.springbootjwt.service;

import com.springbootjwt.model.Cart;

public interface CartService 
{

	Cart getCartByCartId(int cartId);
	
	Cart validate(int cartId);
	
	void update(Cart cart);
}
